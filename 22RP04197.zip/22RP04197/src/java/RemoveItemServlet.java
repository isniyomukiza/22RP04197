
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USER
 */
public class RemoveItemServlet extends HttpServlet {
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String item = request.getParameter("item");
        if (item != null && !item.isEmpty()) {
            Cookie cookie = new Cookie("cartItem_" + item, null);
            cookie.setMaxAge(0); // Delete cookie
            response.addCookie(cookie);
        }
      response.sendRedirect("viewcart");
    }
   
    }
